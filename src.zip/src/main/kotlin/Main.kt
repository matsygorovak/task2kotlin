fun main(args: Array<String>) {
    Parser().parseArgs(args)
}