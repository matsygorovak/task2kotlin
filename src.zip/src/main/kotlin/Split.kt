import org.kohsuke.args4j.CmdLineParser
import java.io.File
import java.io.*

class Split() {
    fun run(
        nameOfFiles: Boolean,
        sizeInLines: Int,
        sizeInChars: Int?,
        countOfFiles: Int?,
        nameOfOutFiles: String?,
        inputFile: String?
    ) {
        val oFile = nameOfOutFiles(inputFile, nameOfOutFiles)
        val list = if (sizeInChars != null) {
            chars(sizeInChars!!, inputFile)
        } else if (countOfFiles != null) {
            count(countOfFiles!!, inputFile)
        } else {
            lines(sizeInLines, inputFile)
        }
        if (nameOfFiles) {
            for (i in 1..list.size + 1) {
                var file = File(oFile + "$i")
                file.createNewFile()
                file.writeText(list[i-1])
            }
        } else {
            var s1 = ""
            var s2 = ""
            for (i in 0..list.size) {
                s1 = ('a' + i / 26).toString()
                s2 = ('a' + i % 26).toString()
                var file = File(oFile + "$s1$s2")
                file.createNewFile()
                file.writeText(list[i])
            }
        }
    }

    //    флаг -o
    private fun nameOfOutFiles(inputFile: String?, outputFile: String?): String {
        if (outputFile!!.isEmpty()) return "x"
        if (outputFile == "-") return inputFile!!
        return outputFile!!
    }

    //    делим по линиям (флаг -l)
    private fun lines(sizeInLines: Int, inputFile: String?): ArrayList<String> {
        var count = 0
        var string = ""
        val list = arrayListOf<String>()
        val file = File(inputFile!!).readLines()
        for (i in file) {
            count++
            string += i + "\n"
            if (count == sizeInLines || count == file.size) {
                string = string.dropLast(1)
                list.add(string)
                count = 0
                string = ""
            }
        }
        return list
    }

    //    делим по символам (флаг -c)
    private fun chars(sizeInChars: Int, inputFile: String?): ArrayList<String> {
        var start = 0
        var end = sizeInChars
        val list = arrayListOf<String>()
        val file = File(inputFile!!).readText()
        while (start < file.length) {
            if (end > file.length - 1) {
                end = file.length
            }
            list.add(file.substring(start, end))
            start += sizeInChars
            end += sizeInChars
        }
        return list
    }

    //    делим по кол-ву файлов
    private fun count(countOfFiles: Int, inputFile: String?): ArrayList<String> {
        val file = File(inputFile!!).readText()
        val co = file.length / countOfFiles
        return chars(co, inputFile)
    }
}

