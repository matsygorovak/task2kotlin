
import org.junit.jupiter.api.Test
import java.io.File
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class Test {

    @Test
    fun test1(){
        main("-d -o outputFile inputFile".split(" ").toTypedArray())
    }
//    @Test
//    fun test2() {
//        try {
//            Split(true, 10, 22, 0, "fileThree", "Empty.txt")
//        } catch (e: Exception) {
//            assertTrue(e: IllegalArgumentException)
//        }
//    }
}